CallShield UZ scaffold for GitHub. This is a starter project; full Gradle wrapper and app code are still needed for a build.
