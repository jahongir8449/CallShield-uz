rootProject.name="CallShield-UZ"
include(":app")
