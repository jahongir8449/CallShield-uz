package com.callshielduz
import android.telecom.Call
import android.telecom.CallScreeningService
class CallBlockService: CallScreeningService(){override fun onScreenCall(details: Call.Details){val r=CallResponse.Builder().setDisallowCall(true).setRejectCall(true).setSkipCallLog(false).build();respondToCall(details,r)}}